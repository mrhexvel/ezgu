-- AlterTable
ALTER TABLE `Category` ADD COLUMN `icon` VARCHAR(191) NULL;
